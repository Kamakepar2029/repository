Metasploit Framework v2 (Archive)
=================================

This repository contains an archived copy of the Metasploit Framework 2.x subversion tree. Please see https://github.com/rapid7/metasploit-framework for active development of the Metasploit Framework.

This was the last commit before the project officially bumped to 3.x, which was a full rewrite using Ruby. Not all author histories have been preserved in this archive.

Screenshot
==========

![](https://github.com/metasploit/framework2/blob/master/images/console.png)
